myemail = ''      #email address with which you wish to send verification emails
mypassword = ''   #get an app password from google account -> security -> app password -> put any custom name -> get that password put here
salt = ''         #create a string of characters that is preferably random then do not change it after setting it!
                  #NOBODY SHOULD SEE THIS SECRET.PY FILE EXCEPT YOU