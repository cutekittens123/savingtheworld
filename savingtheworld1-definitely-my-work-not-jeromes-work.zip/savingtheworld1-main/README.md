### Saving the World 1 - Term 1 Project for my Computing Class.
---------------

[Project Details](https://docs.google.com/document/d/1D4Daka6xcuZB8Wg_MbTXhbfrMkL9DZG11iMpqvgu2Dg/edit)